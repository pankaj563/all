export class Employee {
  id: number;
  name: string;
  address: string;
  company: string;
}
